import websocket
import json
import os
import sys
import time
class MainClient:
    def __init__(self,channel,nick,password,onmessage) -> None:
        self.ws = websocket.create_connection('ws://217.114.47.134:6060/')
        self.nick = nick
        self.channel = channel
        self.password = password
        self.onmessage = onmessage
        self.send({'cmd':'join','channel':channel,'nick':nick,'password':password})
    def send(self,packet):
        self.ws.send(json.dumps(packet))
    def chat(self,text):
        self.send({'cmd':'chat','text':text})
    def whisper(self,nick,text):
        self.send({'cmd':'whisper','nick':nick,'text':text})
    def listen(self):
        while True:
            result = json.loads(self.ws.recv())
            cmd = result['cmd']
            if cmd not in self.onmessage:continue
            if cmd == 'chat':
                if result['nick'] != self.nick and result['nick'] != '机娘':
                    trip = ''
                    if 'trip' in result:
                        trip = result['trip']
                    self.onmessage[cmd](self,result['nick'],trip,result['text'],result)
            elif cmd == 'info':
                if 'type' in result and result['type'] == 'whisper' and 'from' in result:
                    trip = ''
                    if 'trip' in result:
                        trip = result['trip']
                    self.onmessage['whisper'](self,result['nick'],trip,result['msg'])
            
            elif cmd == 'onlineAdd':
                trip = ''
                if 'trip' in result:
                    trip = result['trip']
                self.onmessage[cmd](self,result['nick'],trip)
            elif cmd == 'onlineRemove':
                
                self.onmessage[cmd](self,result['nick'])

def restart():
    py=sys.executable
    os.execl(py,py,*sys.argv)
    sys.exit()
    return

def read_json(file):
    f = open(file,'r')
    txt = f.read()
    f.close()
    return json.loads(txt)

def write_json(file,data):
    f = open(file,'w')
    f.write(json.dumps(data))
    f.close()
    return

def isMod(packet):
    if 'mod' not in packet and 'admin' not in packet:
        return False
    return True

def getOp():
    return read_json('op.json')['op']

def isOp(trip):
    if not trip:return False
    op_list = getOp()
    if trip in op_list:return True
    return False

def onmsg(bot,nick,trip,text,packet):
    if text[0] != '?':
        return
    if not isMod(packet) and not isOp(trip):
        return
    cmdlist = text.split(' ',2)
    cmdlist[0] = cmdlist[0][1:]
    if len(cmdlist) < 2:
        if cmdlist[0] == 'restart':
            if trip != 'mikmike':
                bot.chat(f'>❌ Failed to restart this bot. Reason: insufficient permissions')
            else:
                bot.chat(f'>✅ This bot will restart in 5 seconds')
                time.sleep(5)
                restart()
        elif cmdlist[0] == 'lockroom':
            bot.send({'cmd':'lockroom'})
            payload = json.loads(bot.ws.recv())
            if payload['cmd'] == 'info':
                bot.chat('>✅ This channel was locked')
            else:
                bot.chat('>❌ Failed to lock this channel')
        elif cmdlist[0] == 'unlockroom':
            bot.send({'cmd':'unlockroom'})
            payload = json.loads(bot.ws.recv())
            if payload['cmd'] == 'info':
                bot.chat('>✅ This channel was unlocked')
            else:
                bot.chat('>❌ Failed to unlock this channel')

        elif cmdlist[0] == 'oplist':
            send = ''
            oplist = getOp()
            for i in oplist:
                send += i+'，'
            bot.chat('>✅ At present, the following users are additionally authorized to use this bot:\n'+send[:-1])
        elif cmdlist[0] == 'help':
            bot.whisper(nick,'.\n>✅ At present, this robot has the following functions:\n'+'''\n\
|Name|Level|Usage|
|-:|:-:|:-|
|help|OP|?help|
|lockroom|OP|?lockroom|
|unlockroom|OP|?unlockroom|
|mute|Mod|?mute user-nick|
|unmute|Mod|?unmute user-hash|
|ban|Mod|?ban user-nick|
|kick|OP|?kick user-nick|
|offline|OP|?offline user-nick|
|unban|Mod|?unban user-hash|
|addop|Mod|?addop user-trip|
|delop|Mod|?delop user-trip|
|oplist|OP|?oplist|
|restart|==Owner==|?restart|
''')
        return
    cmdlist[1] = cmdlist[1].replace('@','')
    if cmdlist[0] == 'mute':
        if not isMod(packet):
            bot.chat(f'>❌ Failed to mute {cmdlist[1]}. Reason: insufficient permissions')
            return
        bot.send({'cmd':'dumb','nick':cmdlist[1],'time':0})
        payload = json.loads(bot.ws.recv())
        if payload['cmd'] == 'info':
            bot.chat(f'>✅ {cmdlist[1]} was muted')
        elif payload['cmd'] == 'warn':
            bot.chat(f'>❌ Failed to mute {cmdlist[1]}')
    elif cmdlist[0] == 'unmute':
        if not isMod(packet):
            bot.chat(f'>❌ Failed to unmute hash "{cmdlist[1]}". Reason: insufficient permissions')
            return
        bot.send({'cmd':'speak','hash':cmdlist[1]})
        payload = json.loads(bot.ws.recv())
        if payload['cmd'] == 'info':
            bot.chat(f'>✅Hash "{cmdlist[1]}" was unmuted')
        elif payload['cmd'] == 'warn':
            bot.chat(f'>❌ Failed to unmute hash "{cmdlist[1]}"')
    elif cmdlist[0] == 'ban':
        if not isMod(packet):
            bot.chat(f'>❌ Failed to ban {cmdlist[1]}. Reason: insufficient permissions')
            return

        bot.send({'cmd':'ban','nick':cmdlist[1]})
        payload = json.loads(bot.ws.recv())
        if payload['cmd'] == 'info':
            bot.chat(f'>✅ {cmdlist[1]} was banned')
        elif payload['cmd'] == 'warn':
            bot.chat(f'>❌ Failed to ban {cmdlist[1]}')
    elif cmdlist[0] == 'kick':
        bot.send({'cmd':'kick','nick':cmdlist[1]})
        payload = json.loads(bot.ws.recv())
        if payload['cmd'] == 'info' or payload['cmd'] == 'onlineRemove':
            bot.chat(f'>✅ {cmdlist[1]} was kicked out')
        elif payload['cmd'] == 'warn':
            bot.chat(f'>❌ Failed to kick {cmdlist[1]}')
    elif cmdlist[0] == 'offline':
        bot.send({'cmd':'offline','nick':cmdlist[1]})
        payload = json.loads(bot.ws.recv())
        if payload['cmd'] == 'info':
            bot.chat(f'>✅ {cmdlist[1]} was disconnected')
        elif payload['cmd'] == 'warn':
            bot.chat(f'>❌ Failed to disconnect {cmdlist[1]}')
    elif cmdlist[0] == 'unban':
        if not isMod(packet):
            bot.chat(f'>❌ Failed to unban hash "{cmdlist[1]}". Reason: insufficient permissions')
            return
        bot.send({'cmd':'unban','hash':cmdlist[1]})
        payload = json.loads(bot.ws.recv())
        if payload['cmd'] == 'info':
            bot.chat(f'>✅ Hash "{cmdlist[1]}" was unbanned')
        elif payload['cmd'] == 'warn':
            bot.chat(f'>❌ Failed to unban hash "{cmdlist[1]}"')
    elif cmdlist[0] == 'addop':
        if not isMod(packet):
            bot.chat(f'>❌ Failed to add OP trip "{cmdlist[1]}". Reason: insufficient permissions')
            return
        oplist = getOp()
        if cmdlist[1] in oplist:
            bot.chat(f'>❌ Failed to add OP trip "{cmdlist[1]}". Reason: this trip already exists')
            return
        oplist.append(cmdlist[1])
        write_json('op.json',{'op':oplist})
        bot.chat(f'>✅ Trip "{cmdlist[1]}" was successfully added to the OP list')
    elif cmdlist[0] == 'delop':
        if not isMod(packet):
            bot.chat(f'>❌ Failed to delete OP trip "{cmdlist[1]}". Reason: insufficient permissions')
            return
        oplist = getOp()
        if cmdlist[1] not in oplist:
            bot.chat(f'>❌ Failed to add OP trip "{cmdlist[1]}". Reason: this trip does not exist')
            return
        oplist.remove(cmdlist[1])
        write_json('op.json',{'op':oplist})
        bot.chat(f'>✅ Trip "{cmdlist[1]}" was successfully deleted from the OP list')
dyno = MainClient('lounge','Dyno','Mod\'s password',{'chat':onmsg})
dyno.listen()
